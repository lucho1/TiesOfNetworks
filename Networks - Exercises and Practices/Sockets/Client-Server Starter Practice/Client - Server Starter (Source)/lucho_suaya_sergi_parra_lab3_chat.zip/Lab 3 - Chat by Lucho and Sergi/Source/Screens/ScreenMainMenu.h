#pragma once

class ScreenMainMenu : public Screen
{
private:
	// Virtual functions of Screen
	virtual void Enable() override;
	virtual void GUI() override;
};